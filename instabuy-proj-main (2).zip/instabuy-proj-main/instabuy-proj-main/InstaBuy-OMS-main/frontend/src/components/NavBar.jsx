import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

export default function NavBar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [cartCount, setCartCount] = useState(() => {
    try { return JSON.parse(localStorage.getItem('cart') || '[]').length; } catch { return 0; }
  });

  useEffect(() => {
    setUser(JSON.parse(localStorage.getItem('user') || 'null'));
    setCartCount(() => { try { return JSON.parse(localStorage.getItem('cart') || '[]').length; } catch { return 0; } });
  }, [location]);

  useEffect(() => {
    const onStorage = () => setCartCount(() => { try { return JSON.parse(localStorage.getItem('cart') || '[]').length; } catch { return 0; } });
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const logout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('cart');
    setUser(null);
    setCartCount(0);
    window.dispatchEvent(new Event('storage'));
    navigate('/');
  };

  return (
    <nav className="nav">
      <div className="nav-left">
        <Link to="/" className="nav-brand">Insta<span>Buy</span></Link>
        <Link to="/products" className="nav-link">Products</Link>
        {user?.role !== 'ADMIN' && (
          <Link to="/cart" className="cart-badge">
            🛒 Cart {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
          </Link>
        )}
        {user?.role === 'ADMIN' && (
          <>
            <Link to="/add-product" className="nav-link">+ Add Product</Link>
            <Link to="/orders" className="nav-link">All Orders</Link>
          </>
        )}
        {user && user.role !== 'ADMIN' && (
          <Link to="/orders" className="nav-link">My Orders</Link>
        )}
      </div>

      <div className="nav-right">
        {user ? (
          <>
            <div
              style={{ position: 'relative' }}
              onMouseEnter={() => setShowProfileMenu(true)}
              onMouseLeave={() => setShowProfileMenu(false)}
            >
              <span
                className="nav-user-badge"
                title={`${user.name || user.email} (${user.role})`}
                onClick={() => navigate('/orders')}
              >
                {(user.name || user.email || 'U').trim().charAt(0).toUpperCase()}
              </span>
              {showProfileMenu && (
                <div style={{
                  position: 'absolute', top: 'calc(100% + 6px)', right: 0,
                  background: '#fff', color: '#0f1111', padding: '12px 14px',
                  borderRadius: '6px', boxShadow: '0 4px 20px rgba(0,0,0,.2)',
                  minWidth: '200px', zIndex: 200, border: '1px solid #ddd',
                }}>
                  <p style={{ margin: '0 0 4px', fontWeight: 700, fontSize: 13 }}>{user.name || user.email}</p>
                  <p style={{ margin: '0 0 10px', fontSize: 12, color: '#565959' }}>{user.role}</p>
                  <button
                    style={{ width: '100%', padding: '7px 10px', cursor: 'pointer', fontSize: 13, borderRadius: 4, border: '1px solid #ddd', background: '#f3f3f3' }}
                    onClick={() => navigate('/orders')}
                  >View Orders</button>
                </div>
              )}
            </div>
            <button className="nav-logout" onClick={logout}>Sign Out</button>
          </>
        ) : (
          <>
            <Link to="/login" className="nav-link">Sign In</Link>
            <Link to="/register" className="nav-link">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
