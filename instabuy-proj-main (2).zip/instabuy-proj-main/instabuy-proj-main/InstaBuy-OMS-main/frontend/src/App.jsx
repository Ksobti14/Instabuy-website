import { Routes, Route, Navigate } from 'react-router-dom';
import NavBar from './components/NavBar';
import Home from './pages/Home';
import Products from './pages/Products';
import AddProduct from './pages/AddProduct';
import Orders from './pages/Orders';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Login from './pages/Login';
import Register from './pages/Register';
import NotFound from './pages/NotFound';
import ProtectedRoute from './components/ProtectedRoute';

function AdminGuard({ children }) {
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  return user?.role === 'ADMIN' ? <Navigate to="/" replace /> : children;
}

function App() {
  return (
    <div className="app-shell">
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/cart" element={<AdminGuard><Cart /></AdminGuard>} />
        <Route path="/checkout" element={<AdminGuard><Checkout /></AdminGuard>} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/add-product" element={<ProtectedRoute role="ADMIN"><AddProduct /></ProtectedRoute>} />
        <Route path="/orders" element={<ProtectedRoute><Orders /></ProtectedRoute>} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <footer className="site-footer">
        <p>© 2024 InstaBuy OMS — Built with ❤️ | <a href="/">Home</a> · <a href="/products">Products</a> · <a href="/orders">Orders</a></p>
      </footer>
    </div>
  );
}

export default App;
