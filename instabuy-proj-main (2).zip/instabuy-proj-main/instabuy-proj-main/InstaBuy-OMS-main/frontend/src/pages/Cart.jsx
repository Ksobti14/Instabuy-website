import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

function readCart() { try { return JSON.parse(localStorage.getItem('cart') || '[]'); } catch { return []; } }
const fmt = (v) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(v);

export default function Cart() {
  const [cart, setCart] = useState(readCart());
  const [stockWarning, setStockWarning] = useState({});
  const navigate = useNavigate();

  useEffect(() => { localStorage.setItem('cart', JSON.stringify(cart)); window.dispatchEvent(new Event('storage')); }, [cart]);

  const updateQty = (idx, qty) => {
    const requested = Math.max(1, Number(qty));
    const item = cart[idx];
    const maxStock = item.stock || Infinity;
    if (requested > maxStock) {
      setStockWarning(prev => ({ ...prev, [idx]: `Only ${maxStock} item${maxStock === 1 ? '' : 's'} available in stock.` }));
      const next = [...cart];
      next[idx] = { ...item, quantity: maxStock };
      setCart(next);
    } else {
      setStockWarning(prev => { const n = { ...prev }; delete n[idx]; return n; });
      const next = [...cart];
      next[idx] = { ...item, quantity: requested };
      setCart(next);
    }
  };
  const removeItem = (idx) => {
    setStockWarning(prev => { const n = { ...prev }; delete n[idx]; return n; });
    const next = [...cart]; next.splice(idx, 1); setCart(next);
  };
  const subtotal = cart.reduce((s, it) => s + (it.price || 0) * (it.quantity || 1), 0);
  const shipping = subtotal > 25 ? 0 : 5.99;
  const total = subtotal + shipping;

  return (
    <div className="page-shell">
      <div className="breadcrumb">
        <Link to="/">Home</Link> › <span>Shopping Cart</span>
      </div>
      <h2 style={{ fontSize: '1.6rem', fontWeight: 700, marginBottom: 20 }}>🛒 Shopping Cart</h2>

      {cart.length === 0 ? (
        <div className="panel" style={{ textAlign: 'center', padding: 48 }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>🛒</div>
          <h3 style={{ marginBottom: 8 }}>Your Amazon Cart is empty</h3>
          <p style={{ color: '#565959', marginBottom: 20 }}>Your shopping cart lives here. Start shopping!</p>
          <Link to="/products" className="checkout-btn">Continue Shopping</Link>
        </div>
      ) : (
        <div className="cart-layout">
          <div className="panel">
            <div className="panel-heading">
              <h2>Shopping Cart</h2>
              <span style={{ fontSize: 13, color: '#565959' }}>Price</span>
            </div>
            {cart.map((it, idx) => (
              <div key={idx} className="cart-item">
                <div style={{ fontSize: 48, background: '#f3f3f3', borderRadius: 6, padding: '8px 12px' }}>🛍️</div>
                <div className="cart-item-info">
                  <h3>{it.name}</h3>
                  <p>{it.description}</p>
                  <span className="prime-badge">✓ Prime</span>
                  <p style={{ color: '#007600', fontSize: 12, marginTop: 4 }}>In Stock</p>
                  <div className="cart-item-controls">
                    <label style={{ fontSize: 12, color: '#565959', display: 'flex', alignItems: 'center', gap: 6 }}>
                      Qty:
                      <input type="number" min="1" max={it.stock || undefined} value={it.quantity} onChange={e => updateQty(idx, e.target.value)} />
                    </label>
                    <span style={{ color: '#565959' }}>|</span>
                    <button className="cart-remove-btn" onClick={() => removeItem(idx)}>Delete</button>
                  </div>
                  {stockWarning[idx] && (
                    <p style={{ color: '#b91c1c', fontSize: 12, marginTop: 6, fontWeight: 600 }}>
                      ⚠️ {stockWarning[idx]}
                    </p>
                  )}
                </div>
                <div className="cart-item-price">{fmt((it.price || 0) * (it.quantity || 1))}</div>
              </div>
            ))}
            <div style={{ textAlign: 'right', paddingTop: 16, borderTop: '1px solid #ddd', marginTop: 8 }}>
              <span style={{ fontSize: 16 }}>Subtotal ({cart.reduce((s, i) => s + i.quantity, 0)} items): </span>
              <strong style={{ fontSize: 18, color: '#b12704' }}>{fmt(subtotal)}</strong>
            </div>
          </div>

          <div className="cart-summary">
            <h3>Order Summary</h3>
            <div className="cart-total-row"><span>Subtotal</span><span>{fmt(subtotal)}</span></div>
            <div className="cart-total-row"><span>Shipping</span><span>{shipping === 0 ? <span style={{ color: '#007600' }}>FREE</span> : fmt(shipping)}</span></div>
            {shipping > 0 && <p style={{ fontSize: 11, color: '#007600', marginBottom: 8 }}>Add {fmt(25 - subtotal)} more for FREE shipping</p>}
            <div className="cart-total-row grand"><span>Order Total</span><span style={{ color: '#b12704' }}>{fmt(total)}</span></div>
            <button className="btn-primary" style={{ marginTop: 16 }} onClick={() => navigate('/checkout')}>
              Proceed to Checkout
            </button>
            <p style={{ fontSize: 11, color: '#565959', textAlign: 'center', marginTop: 10 }}>
              🔒 Secure checkout
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
