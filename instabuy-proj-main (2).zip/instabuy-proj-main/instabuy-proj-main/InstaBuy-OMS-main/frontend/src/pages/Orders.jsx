import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const fmt = (v) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(v);

const STATUS_LABEL = {
  PLACED:    { icon: '⏳', text: 'Pending Review', color: '#92400e' },
  ACCEPTED:  { icon: '✅', text: 'Order Accepted', color: '#15803d' },
  CANCELLED: { icon: '❌', text: 'Declined',        color: '#b91c1c' },
  DELIVERED: { icon: '📬', text: 'Delivered',       color: '#15803d' },
};

const TABS = ['All', 'Pending', 'Accepted', 'Declined'];

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState('');
  const [actionError, setActionError] = useState('');
  const [confirmId, setConfirmId] = useState(null);
  const [activeTab, setActiveTab] = useState('All');
  const [currentUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));
  const isAdmin = currentUser?.role?.toUpperCase() === 'ADMIN';

  const loadOrders = () => {
    if (!currentUser) { setError('Please sign in to view orders'); return; }
    const url = isAdmin
      ? '/api/orders'
      : `/api/orders?customerName=${encodeURIComponent((currentUser.name || currentUser.email || '').trim())}`;
    fetch(url).then(r => r.json()).then(setOrders).catch(() => setError('Failed to load orders'));
  };

  useEffect(loadOrders, []);

  const doAction = async (url, method) => {
    setActionError('');
    try {
      const res = await fetch(url, { method });
      if (!res.ok) throw new Error(await res.text());
      loadOrders();
    } catch (e) { setActionError(e.message || 'Action failed'); }
  };

  const acceptOrder  = (id) => doAction(`/api/orders/${id}/accept`,  'PUT');
  const declineOrder = (id) => { setConfirmId(null); doAction(`/api/orders/${id}/cancel`,  'POST'); };
  const restoreOrder = (id) => doAction(`/api/orders/${id}/restore`, 'PUT');

  return (
    <div className="page-shell">
      {/* Decline confirmation modal */}
      {confirmId !== null && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h3 style={{ marginBottom: 10 }}>Decline Order #{confirmId}?</h3>
            <p style={{ color: '#565959', fontSize: 13, marginBottom: 20 }}>
              This will cancel the order. You can undo this afterwards if needed.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button className="order-decline-btn" onClick={() => declineOrder(confirmId)}>Yes, Decline</button>
              <button className="order-undo-btn"    onClick={() => setConfirmId(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      <div className="breadcrumb"><Link to="/">Home</Link> › <span>{isAdmin ? 'All Orders' : 'Your Orders'}</span></div>
      <div className="orders-header">
        <h2>{isAdmin ? '📋 All Orders' : '📦 Your Orders'}</h2>
        {isAdmin && <span style={{ fontSize: 13, color: '#565959' }}>{orders.length} total orders</span>}
      </div>

      {error       && <div className="alert error" style={{ marginBottom: 16 }}>{error}</div>}
      {actionError && <div className="alert error" style={{ marginBottom: 16 }}>{actionError}</div>}

      {isAdmin && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
          {TABS.map(tab => {
            const count = tab === 'All'      ? orders.length
                        : tab === 'Pending'  ? orders.filter(o => o.status === 'PLACED').length
                        : tab === 'Accepted' ? orders.filter(o => o.status === 'ACCEPTED').length
                        : orders.filter(o => o.status === 'CANCELLED').length;
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={activeTab === tab ? 'tab-btn active' : 'tab-btn'}
              >
                {tab === 'Pending' && '⏳ '}{tab === 'Accepted' && '✅ '}{tab === 'Declined' && '❌ '}
                {tab} <span className="tab-count">{count}</span>
              </button>
            );
          })}
        </div>
      )}

      {orders.length === 0 && !error ? (
        <div className="panel" style={{ textAlign: 'center', padding: 48 }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>📦</div>
          <h3 style={{ marginBottom: 8 }}>{isAdmin ? 'No orders yet' : 'No orders placed yet'}</h3>
          <p style={{ color: '#565959', marginBottom: 20 }}>
            {isAdmin ? 'Orders will appear here once customers start shopping.' : 'When you place an order, it will appear here.'}
          </p>
          {!isAdmin && <Link to="/products" className="checkout-btn">Start Shopping</Link>}
        </div>
      ) : (
        <div className="order-list">
          {orders.filter(o => {
            if (!isAdmin || activeTab === 'All') return true;
            if (activeTab === 'Pending')  return o.status === 'PLACED';
            if (activeTab === 'Accepted') return o.status === 'ACCEPTED';
            if (activeTab === 'Declined') return o.status === 'CANCELLED';
            return true;
          }).map(o => {
            const s = STATUS_LABEL[o.status] || { icon: '📦', text: o.status, color: '#565959' };
            return (
              <div key={o.id} className="order-card">
                <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', flex: 1 }}>
                  <div style={{ fontSize: 36, background: '#f3f3f3', borderRadius: 6, padding: '8px 12px', flexShrink: 0 }}>📦</div>
                  <div style={{ flex: 1 }}>
                    <strong style={{ fontSize: 15 }}>Order #{o.id}</strong>
                    {o.product && (
                      <>
                        <p style={{ fontWeight: 600, color: 'var(--amz-text)', marginTop: 2 }}>{o.product.name}</p>
                        {o.product.sku && <p style={{ fontSize: 11, color: '#2563eb', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.05em' }}>SKU: {o.product.sku}</p>}
                        {o.product.description && <p style={{ fontSize: 12, color: 'var(--amz-muted)', marginTop: 2 }}>{o.product.description}</p>}
                      </>
                    )}
                    {isAdmin && <p style={{ marginTop: 4 }}>Customer: <strong>{o.customerName}</strong></p>}
                    {o.createdAt && (
                      <p style={{ fontSize: 12, color: 'var(--amz-muted)', marginTop: 2 }}>
                        🕐 {new Date(o.createdAt).toLocaleString()}
                      </p>
                    )}
                    <p style={{ color: s.color, fontSize: 13, fontWeight: 600, marginTop: 4 }}>
                      {s.icon} {s.text}
                    </p>
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, minWidth: 160 }}>
                  <span className={`status-badge ${o.status}`}>{o.status}</span>
                  <span style={{ fontSize: 13, color: '#565959' }}>Qty: <strong>{o.quantity}</strong></span>
                  {o.product?.price && (
                    <span style={{ fontSize: 12, color: 'var(--amz-muted)' }}>
                      {fmt(o.product.price)} × {o.quantity}
                    </span>
                  )}
                  {o.product?.price && (
                    <span style={{ fontSize: 16, fontWeight: 800, color: '#b12704' }}>
                      {fmt(o.product.price * o.quantity)}
                    </span>
                  )}

                  {isAdmin && o.status === 'PLACED' && (
                    <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                      <button className="order-accept-btn"  onClick={() => acceptOrder(o.id)}>✓ Accept</button>
                      <button className="order-decline-btn" onClick={() => setConfirmId(o.id)}>✕ Decline</button>
                    </div>
                  )}

                  {isAdmin && o.status === 'CANCELLED' && (
                    <button className="order-undo-btn" onClick={() => restoreOrder(o.id)}>↩ Undo Decline</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
