import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

export default function AddProduct() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', description: '', price: 0, stock: 0, sku: '' });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(''); setSuccess(''); setLoading(true);
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, price: Number(form.price), stock: Number(form.stock) }),
      });
      if (!res.ok) { const t = await res.text(); throw new Error(t || 'Create failed'); }
      setSuccess('✅ Product created successfully!');
      setTimeout(() => navigate('/products'), 1200);
    } catch (e) { setError(e.message || 'Failed to create product'); }
    finally { setLoading(false); }
  };

  return (
    <div className="page-shell">
      <div className="breadcrumb"><Link to="/">Home</Link> › <Link to="/products">Products</Link> › <span>Add Product</span></div>
      <div className="add-product-wrapper">
        <div className="panel">
          <h2 style={{ marginBottom: 20 }}>➕ Add New Product</h2>
          {error && <div className="alert error" style={{ marginBottom: 14 }}>{error}</div>}
          {success && <div className="alert success" style={{ marginBottom: 14 }}>{success}</div>}
          <form className="order-form" onSubmit={handleSubmit}>
            <label>Product Name <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required placeholder="e.g. Wireless Headphones" /></label>
            <label>SKU <input value={form.sku} onChange={e => setForm({ ...form, sku: e.target.value })} placeholder="e.g. WH-1000XM5" /></label>
            <label>Description <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Product description..." /></label>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <label>Price ($) <input type="number" step="0.01" min="0" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} required /></label>
              <label>Stock Quantity <input type="number" min="0" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} required /></label>
            </div>
            <button className="btn-primary" type="submit" disabled={loading} style={{ marginTop: 8 }}>
              {loading ? 'Creating...' : 'Create Product'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
