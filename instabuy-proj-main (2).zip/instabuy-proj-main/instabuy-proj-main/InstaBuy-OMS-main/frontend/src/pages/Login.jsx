import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) { let t = await res.text(); try { const j = JSON.parse(t); t = j.message || j.error || t; } catch {} throw new Error(t || 'Login failed'); }
      const data = await res.json();
      if (data.role === 'ADMIN') {
        // verify it's the real admin
      }
      localStorage.setItem('user', JSON.stringify({ token: data.token, email: data.email, name: data.name, role: data.role }));
      navigate('/');
    } catch (e) {
      const ADMIN_EMAIL = 'kanavsobti@gmail.com';
      if (email.trim().toLowerCase() === ADMIN_EMAIL) {
        setError('Incorrect admin credentials. Only the authorized admin can sign in with this email.');
      } else {
        setError(e.message || 'Login failed');
      }
    }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-box">
        <h2>Sign In</h2>
        {error && <div className="alert error" style={{ marginBottom: 14 }}>{error}</div>}
        <form className="order-form" onSubmit={handle}>
          <label>
            Email or mobile phone number
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} required autoFocus />
          </label>
          <label>
            Password
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
          </label>
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
        <p style={{ fontSize: 11, color: '#565959', margin: '14px 0', textAlign: 'center' }}>
          By continuing, you agree to InstaBuy's Conditions of Use and Privacy Notice.
        </p>
        <div className="auth-divider">New to InstaBuy?</div>
        <Link to="/register" className="checkout-btn" style={{ display: 'block', textAlign: 'center', marginTop: 12, background: 'linear-gradient(to bottom,#fff,#f3f3f3)', border: '1px solid #ddd' }}>
          Create your InstaBuy account
        </Link>
      </div>
    </div>
  );
}
