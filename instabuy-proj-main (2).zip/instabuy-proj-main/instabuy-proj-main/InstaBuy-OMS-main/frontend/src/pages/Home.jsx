import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import LoginModal from '../components/LoginModal';

const fmt = (v) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(v);

export default function Home() {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [showLogin, setShowLogin] = useState(false);
  const [currentUser, setCurrentUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));

  const featured = useMemo(() => products.slice(0, 4), [products]);
  const isAdmin = currentUser?.role?.toUpperCase() === 'ADMIN';

  useEffect(() => {
    setCurrentUser(JSON.parse(localStorage.getItem('user') || 'null'));
    fetch('/api/products').then(r => r.json()).then(setProducts).catch(() => {});
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    if (user) {
      const isAdm = user.role?.toUpperCase() === 'ADMIN';
      const url = isAdm ? '/api/orders' : `/api/orders?customerName=${encodeURIComponent((user.name || user.email || '').trim())}`;
      fetch(url).then(r => r.json()).then(setOrders).catch(() => {});
    }
  }, [showLogin]);

  const addToCart = (p) => {
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    if (!user) { setShowLogin(true); return; }
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const ex = cart.find(c => Number(c.id) === Number(p.id));
    if (ex) ex.quantity = Math.min((Number(ex.quantity) || 1) + 1, p.stock);
    else cart.push({ id: p.id, productId: p.id, name: p.name, description: p.description, price: p.price, quantity: 1, stock: p.stock });
    localStorage.setItem('cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('storage'));
  };

  return (
    <div>
      {/* Hero Banner */}
      <div className="hero-panel" style={{ borderRadius: 0, marginBottom: 0 }}>
        <p className="eyebrow">🛍️ InstaBuy OMS</p>
        <h1>Shop Smarter.<br />Deliver Faster.</h1>
        <p className="hero-text">
          Millions of products. Unbeatable prices. Fast delivery. Your one-stop shop for everything you need.
        </p>
        {!isAdmin && <Link to="/products" className="hero-cta">Shop Now →</Link>}
      </div>

      <div className="page-shell">
        {/* Stats strip for admin */}
        {isAdmin && (
          <div style={{ display: 'flex', gap: 16, marginBottom: 20, flexWrap: 'wrap' }}>
            {[
              { label: 'Total Orders', value: orders.length, icon: '📦' },
              { label: 'Products Listed', value: products.length, icon: '🏷️' },
              { label: 'Pending Orders', value: orders.filter(o => o.status === 'PLACED').length, icon: '⏳' },
            ].map(s => (
              <div key={s.label} className="panel" style={{ flex: '1 1 160px', textAlign: 'center' }}>
                <div style={{ fontSize: 28 }}>{s.icon}</div>
                <div style={{ fontSize: 28, fontWeight: 800, color: '#b12704' }}>{s.value}</div>
                <div style={{ fontSize: 12, color: '#565959', marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Welcome panel for guests */}
        {!currentUser && (
          <div className="panel card-highlight" style={{ marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
            <div>
              <h2 style={{ marginBottom: 4 }}>Welcome to InstaBuy</h2>
              <p style={{ color: '#565959', fontSize: 13 }}>Sign in for the best experience — track orders, save items, and more.</p>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <Link to="/login" className="checkout-btn">Sign In</Link>
              <Link to="/register" className="checkout-btn" style={{ background: 'linear-gradient(to bottom,#fff,#f3f3f3)', border: '1px solid #ddd' }}>Create Account</Link>
            </div>
          </div>
        )}

        {/* Featured Products */}
        <div className="panel" style={{ marginBottom: 20 }}>
          <div className="panel-heading">
            <h2>⭐ Featured Products</h2>
            <Link to="/products" style={{ fontSize: 13, color: '#007185' }}>See all products →</Link>
          </div>
          {featured.length === 0 ? (
            <p className="empty-state">No products available. {isAdmin ? 'Add some products to get started.' : 'Check back soon!'}</p>
          ) : (
            <div className="product-grid">
              {featured.map(p => (
                <div key={p.id} className="product-card">
                  <div style={{ fontSize: 40, textAlign: 'center', padding: '12px 0', background: '#f3f3f3', borderRadius: 6, marginBottom: 8 }}>🛍️</div>
                  <p className="product-sku">{p.sku}</p>
                  <h3>{p.name}</h3>
                  <p>{p.description}</p>
                  <div className="stars">★★★★☆</div>
                  <div className="product-meta">
                    <span>{fmt(p.price)}</span>
                    <span>{p.stock > 0 ? `${p.stock} in stock` : 'Out of stock'}</span>
                  </div>
                  {!isAdmin && (
                    <button className="checkout-btn" style={{ width: '100%', marginTop: 8 }} onClick={() => addToCart(p)} disabled={p.stock === 0}>
                      {p.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Orders for admin */}
        {isAdmin && orders.length > 0 && (
          <div className="panel">
            <div className="panel-heading">
              <h2>📋 Recent Orders</h2>
              <Link to="/orders" style={{ fontSize: 13, color: '#007185' }}>View all →</Link>
            </div>
            <div className="order-list">
              {orders.slice(0, 5).map(o => (
                <div key={o.id} className="order-card">
                  <div>
                    <strong>Order #{o.id}</strong>
                    <p>{o.product?.name}</p>
                    <p>Customer: {o.customerName}</p>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
                    <span>{o.quantity} pcs</span>
                    <span className={`status-badge ${o.status}`}>{o.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <LoginModal open={showLogin} onClose={() => setShowLogin(false)} onSuccess={() => setShowLogin(false)} />
    </div>
  );
}
