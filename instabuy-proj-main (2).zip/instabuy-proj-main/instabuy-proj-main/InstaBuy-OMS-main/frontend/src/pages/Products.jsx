import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const fmt = (v) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(v);

export default function Products() {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const currentUser = JSON.parse(localStorage.getItem('user') || 'null');
  const isAdmin = currentUser?.role === 'ADMIN';

  useEffect(() => { fetchProducts(); }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      setProducts(await res.json());
    } catch { setError('Failed to load products. Is the backend running?'); }
  };

  const updateStock = async (id, stock) => {
    try {
      const res = await fetch(`/api/products/${id}/stock?stock=${stock}`, { method: 'PUT' });
      if (!res.ok) throw new Error('Update failed');
      await fetchProducts();
    } catch (e) { setError(e.message || 'Failed to update stock'); }
  };

  const addToCart = (p) => {
    if (!currentUser) { navigate('/login'); return; }
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const ex = cart.find(c => Number(c.id) === Number(p.id));
    if (ex) ex.quantity = Math.min((Number(ex.quantity) || 1) + 1, p.stock);
    else cart.push({ id: p.id, productId: p.id, name: p.name, description: p.description, price: p.price, quantity: 1, stock: p.stock });
    localStorage.setItem('cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('storage'));
  };

  return (
    <div className="page-shell">
      <div className="products-header">
        <h2>🏷️ All Products</h2>
        <span style={{ fontSize: 13, color: '#565959' }}>{products.length} items</span>
      </div>

      {error && <div className="alert error" style={{ marginBottom: 16 }}>{error}<button className="checkout-btn" style={{ marginLeft: 12 }} onClick={fetchProducts}>Retry</button></div>}

      <div className="product-grid">
        {products.map(p => (
          <div key={p.id} className="product-card">
            <div style={{ fontSize: 48, textAlign: 'center', padding: '16px 0', background: '#f3f3f3', borderRadius: 6, marginBottom: 8 }}>🛍️</div>
            <p className="product-sku">{p.sku}</p>
            <h3>{p.name}</h3>
            <p>{p.description}</p>
            <div className="stars">★★★★☆ <span style={{ color: '#007185', fontSize: 12 }}>(42)</span></div>
            <div className="product-meta">
              <span>{fmt(p.price)}</span>
              <span style={{ color: p.stock > 0 ? '#007600' : '#b12704' }}>
                {p.stock > 0 ? `In Stock (${p.stock})` : 'Out of Stock'}
              </span>
            </div>
            <span className="prime-badge">✓ Prime</span>
            <div className="product-actions">
              {isAdmin ? (
                <label style={{ fontSize: 12, color: '#565959' }}>
                  Update Stock:
                  <input type="number" defaultValue={p.stock} onBlur={e => updateStock(p.id, e.target.value)} />
                </label>
              ) : (
                <button
                  className="checkout-btn"
                  style={{ width: '100%' }}
                  onClick={() => addToCart(p)}
                  disabled={p.stock === 0}
                >
                  {p.stock === 0 ? 'Out of Stock' : '🛒 Add to Cart'}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
