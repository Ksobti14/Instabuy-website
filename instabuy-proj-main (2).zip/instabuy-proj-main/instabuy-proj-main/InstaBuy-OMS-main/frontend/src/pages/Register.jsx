import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm]       = useState({ name: '', email: '', password: '' });
  const [otp, setOtp]         = useState('');
  const [step, setStep]       = useState(1); // 1 = form, 2 = otp
  const [error, setError]     = useState('');
  const [info, setInfo]       = useState('');
  const [loading, setLoading] = useState(false);

  const sendOtp = async (e) => {
    e.preventDefault();
    setError(''); setInfo('');
    if (!form.name || !form.email || !form.password) { setError('All fields are required.'); return; }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, name: form.name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to send OTP');
      setInfo(`A 6-digit OTP has been sent to ${form.email}`);
      setStep(2);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  };

  const verifyAndRegister = async (e) => {
    e.preventDefault();
    setError(''); setInfo('');
    if (!otp) { setError('Please enter the OTP.'); return; }
    setLoading(true);
    try {
      // 1. verify OTP
      const vRes = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, otp }),
      });
      const vData = await vRes.json();
      if (!vRes.ok) throw new Error(vData.error || 'Invalid OTP');

      // 2. register
      const rRes = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, role: 'CUSTOMER' }),
      });
      if (!rRes.ok) { let t = await rRes.text(); try { const j = JSON.parse(t); t = j.message || j.error || t; } catch {} throw new Error(t); }
      const data = await rRes.json();
      localStorage.setItem('user', JSON.stringify({ token: data.token, email: data.email, name: data.name, role: data.role }));
      navigate('/');
    } catch (e) { setError(e.message || 'Registration failed'); }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-wrapper">
      <div className="auth-box" style={{ maxWidth: 420 }}>
        <h2>{step === 1 ? 'Create Account' : 'Verify Your Email'}</h2>

        {/* step indicator */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          {['Details', 'Verify Email'].map((label, i) => (
            <div key={i} style={{ flex: 1, textAlign: 'center' }}>
              <div style={{
                height: 4, borderRadius: 2, marginBottom: 4,
                background: step > i ? '#e85c2e' : step === i + 1 ? '#e85c2e' : '#e2e8f0',
              }} />
              <span style={{ fontSize: 11, color: step === i + 1 ? '#e85c2e' : '#94a3b8', fontWeight: 600 }}>{label}</span>
            </div>
          ))}
        </div>

        {error && <div className="alert error" style={{ marginBottom: 14 }}>{error}</div>}
        {info  && <div className="alert success" style={{ marginBottom: 14 }}>{info}</div>}

        {step === 1 ? (
          <form className="order-form" onSubmit={sendOtp}>
            <label>
              Your name
              <input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="First and last name" required autoFocus />
            </label>
            <label>
              Email
              <input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
            </label>
            <label>
              Password
              <input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="At least 6 characters" required />
            </label>
            <button className="btn-primary" type="submit" disabled={loading}>
              {loading ? 'Sending OTP...' : 'Send Verification Code →'}
            </button>
          </form>
        ) : (
          <form className="order-form" onSubmit={verifyAndRegister}>
            <p style={{ fontSize: 13, color: '#64748b', marginBottom: 4 }}>
              Enter the 6-digit code sent to <strong>{form.email}</strong>
            </p>
            <label>
              OTP Code
              <input
                value={otp}
                onChange={e => setOtp(e.target.value)}
                placeholder="000000"
                maxLength={6}
                style={{ letterSpacing: '0.3em', fontSize: 20, textAlign: 'center' }}
                autoFocus
                required
              />
            </label>
            <button className="btn-primary" type="submit" disabled={loading}>
              {loading ? 'Verifying...' : 'Verify & Create Account'}
            </button>
            <button
              type="button"
              style={{ background: 'none', border: 'none', color: '#2563eb', fontSize: 13, cursor: 'pointer', textAlign: 'center' }}
              onClick={() => { setStep(1); setOtp(''); setError(''); setInfo(''); }}
            >
              ← Change email or details
            </button>
          </form>
        )}

        <p style={{ fontSize: 11, color: '#565959', margin: '14px 0', textAlign: 'center' }}>
          By creating an account, you agree to InstaBuy's Conditions of Use and Privacy Notice.
        </p>
        <div className="auth-divider">Already have an account?</div>
        <Link to="/login" className="checkout-btn" style={{ display: 'block', textAlign: 'center', marginTop: 12, background: 'linear-gradient(to bottom,#fff,#f3f3f3)', border: '1px solid #ddd' }}>
          Sign In
        </Link>
      </div>
    </div>
  );
}
