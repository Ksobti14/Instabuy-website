package com.instabuy.oms.enums;

public enum OrderStatus {
    PLACED,
    ACCEPTED,
    CANCELLED
}
