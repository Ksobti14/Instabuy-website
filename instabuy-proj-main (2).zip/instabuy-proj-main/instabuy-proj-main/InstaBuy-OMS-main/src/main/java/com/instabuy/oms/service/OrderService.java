package com.instabuy.oms.service;

import com.instabuy.oms.constants.AppConstants;
import com.instabuy.oms.dto.OrderRequest;
import com.instabuy.oms.dto.OrderResponse;
import com.instabuy.oms.entity.OrderEntity;
import com.instabuy.oms.entity.Product;
import com.instabuy.oms.enums.OrderStatus;
import com.instabuy.oms.mapper.OrderMapper;
import com.instabuy.oms.repository.OrderRepository;
import com.instabuy.oms.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductService productService;
    private final ProductRepository productRepository;
    private final OrderMapper orderMapper;

    public OrderResponse toResponse(OrderEntity order) {
        OrderResponse r = new OrderResponse();
        r.setId(order.getId());
        r.setCustomerName(order.getCustomerName());
        r.setQuantity(order.getQuantity());
        r.setStatus(order.getStatus());
        r.setCreatedAt(order.getCreatedAt());
        productRepository.findById(order.getProductId()).ifPresent(r::setProduct);
        return r;
    }

    public List<OrderResponse> getAllOrders() {
        log.debug("Fetching all orders");
        return orderRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<OrderResponse> getOrdersByCustomerName(String customerName) {
        log.debug("Fetching orders for customer: {}", customerName);
        return orderRepository.findByCustomerNameIgnoreCase(customerName).stream().map(this::toResponse).collect(Collectors.toList());
    }

    public OrderEntity getOrderById(Long id) {
        log.debug("Fetching order by id: {}", id);
        return orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(AppConstants.ORDER_NOT_FOUND + id));
    }

    @Transactional
    public OrderResponse createOrder(OrderRequest request) {
        log.info("Creating order for customer: {}, product: {}", request.getCustomerName(), request.getProductId());
        productService.reduceStock(request.getProductId(), request.getQuantity());
        OrderEntity order = orderMapper.toEntity(request);
        order.setStatus(OrderStatus.PLACED);
        OrderEntity saved = orderRepository.save(order);
        log.info("Order created with id: {}", saved.getId());
        return toResponse(saved);
    }

    @Transactional
    public OrderResponse acceptOrder(Long orderId) {
        log.info("Accepting order: {}", orderId);
        OrderEntity order = getOrderById(orderId);
        if (order.getStatus() != OrderStatus.PLACED)
            throw new IllegalStateException("Only PLACED orders can be accepted");
        order.setStatus(OrderStatus.ACCEPTED);
        log.info("Order {} accepted successfully", orderId);
        return toResponse(orderRepository.save(order));
    }

    @Transactional
    public OrderResponse cancelOrder(Long orderId) {
        log.info("Cancelling order: {}", orderId);
        OrderEntity order = getOrderById(orderId);
        if (order.getStatus() != OrderStatus.PLACED && order.getStatus() != OrderStatus.ACCEPTED)
            throw new IllegalStateException(AppConstants.ONLY_PLACED_ORDERS_CANCELLED);
        productService.restoreStock(order.getProductId(), order.getQuantity());
        order.setStatus(OrderStatus.CANCELLED);
        log.info("Order {} cancelled successfully", orderId);
        return toResponse(orderRepository.save(order));
    }

    @Transactional
    public OrderResponse restoreOrder(Long orderId) {
        log.info("Restoring cancelled order: {}", orderId);
        OrderEntity order = getOrderById(orderId);
        if (order.getStatus() != OrderStatus.CANCELLED)
            throw new IllegalStateException("Only CANCELLED orders can be restored");
        productService.reduceStock(order.getProductId(), order.getQuantity());
        order.setStatus(OrderStatus.PLACED);
        log.info("Order {} restored to PLACED", orderId);
        return toResponse(orderRepository.save(order));
    }
}
