package com.instabuy.oms.service;

import com.instabuy.oms.constants.AppConstants;
import com.instabuy.oms.dto.AuthRequest;
import com.instabuy.oms.dto.AuthResponse;
import com.instabuy.oms.entity.User;
import com.instabuy.oms.enums.UserRole;
import com.instabuy.oms.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;

    public AuthResponse register(AuthRequest request) {
        log.info("Registering user with email: {}", request.getEmail());

        if (request.getRole() != null && request.getRole().equalsIgnoreCase("ADMIN"))
            throw new IllegalArgumentException("Admin accounts cannot be created through registration.");

        if (userRepository.findByEmail(request.getEmail()).isPresent())
            throw new IllegalArgumentException(AppConstants.EMAIL_ALREADY_REGISTERED);

        User user = new User();
        user.setEmail(request.getEmail());
        user.setPassword(Base64.getEncoder().encodeToString(request.getPassword().getBytes()));
        user.setName(request.getName());
        user.setRole(parseRole(request.getRole()));

        user = userRepository.save(user);
        log.info("User registered successfully: {}", user.getEmail());
        return buildAuthResponse(user);
    }

    public AuthResponse login(AuthRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException(AppConstants.INVALID_CREDENTIALS));

        if (!Base64.getEncoder().encodeToString(request.getPassword().getBytes()).equals(user.getPassword()))
            throw new IllegalArgumentException(AppConstants.INVALID_CREDENTIALS);

        log.info("Login successful for: {}", user.getEmail());
        return buildAuthResponse(user);
    }

    private UserRole parseRole(String role) {
        try {
            return UserRole.valueOf(role.toUpperCase());
        } catch (Exception e) {
            return UserRole.CUSTOMER;
        }
    }

    private String generateToken(User user) {
        return Base64.getEncoder().encodeToString(
                (user.getId() + ":" + user.getEmail() + ":" + user.getRole()).getBytes());
    }

    private AuthResponse buildAuthResponse(User user) {
        return new AuthResponse(generateToken(user), user.getEmail(), user.getName(), user.getRole().name());
    }
}
