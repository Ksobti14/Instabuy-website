package com.instabuy.oms.service;

import com.instabuy.oms.constants.AppConstants;
import com.instabuy.oms.entity.Product;
import com.instabuy.oms.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public List<Product> getAllProducts() {
        log.debug("Fetching all products");
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        log.debug("Fetching product by id: {}", id);
        return productRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(AppConstants.PRODUCT_NOT_FOUND + id));
    }

    @Transactional
    public Product createProduct(Product product) {
        log.info("Creating product: {}", product.getSku());
        return productRepository.save(product);
    }

    @Transactional
    public void reduceStock(Long productId, int quantity) {
        Product product = getProductById(productId);
        if (product.getStock() < quantity)
            throw new IllegalStateException(AppConstants.INSUFFICIENT_STOCK + product.getSku());
        product.setStock(product.getStock() - quantity);
        productRepository.save(product);
        log.info("Stock reduced for product {}: -{}", product.getSku(), quantity);
    }

    @Transactional
    public void restoreStock(Long productId, int quantity) {
        Product product = getProductById(productId);
        product.setStock(product.getStock() + quantity);
        productRepository.save(product);
        log.info("Stock restored for product {}: +{}", product.getSku(), quantity);
    }

    @Transactional
    public Product updateStock(Long productId, int stock) {
        Product product = getProductById(productId);
        product.setStock(stock);
        log.info("Stock updated for product {}: {}", product.getSku(), stock);
        return productRepository.save(product);
    }

    public void seedDefaultProducts() {
        if (productRepository.count() > 0) return;
        log.info("Seeding default products");
        productRepository.save(new Product(null, AppConstants.SKU_1001, "Smartphone", "Premium Android phone", new BigDecimal("499.99"), 120));
        productRepository.save(new Product(null, AppConstants.SKU_1002, "Wireless Earbuds", "Noise-cancelling Bluetooth earbuds", new BigDecimal("89.99"), 200));
        productRepository.save(new Product(null, AppConstants.SKU_1003, "Fitness Tracker", "Wearable health and workout tracker", new BigDecimal("69.99"), 175));
    }
}
