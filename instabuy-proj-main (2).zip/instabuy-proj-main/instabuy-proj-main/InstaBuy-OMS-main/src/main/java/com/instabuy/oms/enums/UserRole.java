package com.instabuy.oms.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER
}
