package com.instabuy.oms.controller;

import com.instabuy.oms.dto.AuthRequest;
import com.instabuy.oms.dto.AuthResponse;
import com.instabuy.oms.service.AuthService;
import com.instabuy.oms.service.EmailService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final EmailService emailService;

    public AuthController(AuthService authService, EmailService emailService) {
        this.authService = authService;
        this.emailService = emailService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@RequestBody AuthRequest request) {
        AuthResponse response = authService.register(request);
        emailService.sendWelcome(request.getEmail(), request.getName());
        return ResponseEntity.ok(response);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/send-otp")
    public ResponseEntity<Map<String, String>> sendOtp(@RequestBody Map<String, String> body) {
        String email = body.getOrDefault("email", "").trim();
        String name  = body.getOrDefault("name",  "").trim();
        if (email.isEmpty()) return ResponseEntity.badRequest().body(Map.of("error", "Email is required"));
        emailService.sendOtp(email, name);
        return ResponseEntity.ok(Map.of("message", "OTP sent to " + email));
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<Map<String, String>> verifyOtp(@RequestBody Map<String, String> body) {
        String email = body.getOrDefault("email", "").trim();
        String otp   = body.getOrDefault("otp",   "").trim();
        if (emailService.verifyOtp(email, otp))
            return ResponseEntity.ok(Map.of("message", "verified"));
        return ResponseEntity.badRequest().body(Map.of("error", "Invalid or expired OTP"));
    }
}
