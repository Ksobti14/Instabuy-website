package com.instabuy.oms.repository;

import com.instabuy.oms.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByCustomerNameIgnoreCase(String customerName);
}
