package com.instabuy.oms.enums;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED
}
