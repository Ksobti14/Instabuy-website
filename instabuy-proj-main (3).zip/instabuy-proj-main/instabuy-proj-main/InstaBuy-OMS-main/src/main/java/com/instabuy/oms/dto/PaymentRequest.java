package com.instabuy.oms.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class PaymentRequest {

    @NotBlank(message = "Customer name is required")
    private String customerName;

    private Double amount;

    @NotEmpty(message = "Items list cannot be empty")
    private List<OrderRequest> items;
}
