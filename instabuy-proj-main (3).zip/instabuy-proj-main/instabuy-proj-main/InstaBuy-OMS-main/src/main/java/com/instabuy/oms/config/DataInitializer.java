package com.instabuy.oms.config;

import com.instabuy.oms.entity.User;
import com.instabuy.oms.enums.UserRole;
import com.instabuy.oms.repository.UserRepository;
import com.instabuy.oms.service.ProductService;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Component
public class DataInitializer {

    private final ProductService productService;
    private final UserRepository userRepository;

    public DataInitializer(ProductService productService, UserRepository userRepository) {
        this.productService = productService;
        this.userRepository = userRepository;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void init() {
        productService.seedDefaultProducts();
        seedAdminUser();
    }

    private void seedAdminUser() {
        String email = "kanavsobti@gmail.com";
        String encodedPassword = Base64.getEncoder().encodeToString("Kan@200412".getBytes());
        User admin = userRepository.findByEmail(email).orElse(new User());
        admin.setEmail(email);
        admin.setName("Kanav Sobti");
        admin.setPassword(encodedPassword);
        admin.setRole(UserRole.ADMIN);
        userRepository.save(admin);
    }
}
