package com.instabuy.oms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstaBuyOmsApplication {
    public static void main(String[] args) {
        SpringApplication.run(InstaBuyOmsApplication.class, args);
    }
}
