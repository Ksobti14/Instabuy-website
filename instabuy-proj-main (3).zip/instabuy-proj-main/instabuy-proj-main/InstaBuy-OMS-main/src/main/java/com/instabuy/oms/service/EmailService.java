package com.instabuy.oms.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import jakarta.mail.internet.MimeMessage;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailService {

    private final JavaMailSender mailSender;

    // email -> otp (in-memory, expires after use)
    private final Map<String, String> otpStore = new ConcurrentHashMap<>();

    public void sendOtp(String toEmail, String name) {
        String otp = String.format("%06d", new Random().nextInt(1000000));
        otpStore.put(toEmail.toLowerCase(), otp);

        String subject = "InstaBuy — Your Verification Code";
        String body = """
                <div style="font-family:Segoe UI,Arial,sans-serif;max-width:480px;margin:0 auto;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
                  <div style="background:#1b2a4a;padding:24px 32px">
                    <h1 style="color:#fff;margin:0;font-size:1.4rem">Insta<span style="color:#f4a261">Buy</span></h1>
                  </div>
                  <div style="padding:32px">
                    <h2 style="margin:0 0 12px;color:#1e293b">Hi %s 👋</h2>
                    <p style="color:#64748b;margin:0 0 24px">Use the code below to verify your email address. It is valid for this session only.</p>
                    <div style="background:#f1f5f9;border-radius:8px;padding:20px;text-align:center;letter-spacing:8px;font-size:2rem;font-weight:800;color:#1b2a4a">%s</div>
                    <p style="color:#94a3b8;font-size:12px;margin:20px 0 0">If you didn't request this, you can safely ignore this email.</p>
                  </div>
                </div>
                """.formatted(name.isBlank() ? "there" : name, otp);

        if (!sendHtml(toEmail, subject, body))
            throw new IllegalStateException("Unable to send OTP. Please check mail configuration.");

        log.info("OTP sent to {}", toEmail);
    }

    public boolean verifyOtp(String email, String otp) {
        String stored = otpStore.get(email.toLowerCase());
        if (stored != null && stored.equals(otp.trim())) {
            otpStore.remove(email.toLowerCase());
            return true;
        }
        return false;
    }

    public void sendWelcome(String toEmail, String name) {
        String subject = "Welcome to InstaBuy! 🎉";
        String body = """
                <div style="font-family:Segoe UI,Arial,sans-serif;max-width:480px;margin:0 auto;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden">
                  <div style="background:linear-gradient(135deg,#1b2a4a,#243b6e);padding:32px;text-align:center">
                    <h1 style="color:#fff;margin:0 0 8px;font-size:1.6rem">Insta<span style="color:#f4a261">Buy</span></h1>
                    <p style="color:rgba(255,255,255,.7);margin:0;font-size:14px">Your one-stop shop for everything</p>
                  </div>
                  <div style="padding:32px">
                    <h2 style="margin:0 0 12px;color:#1e293b">Welcome aboard, %s! 🎊</h2>
                    <p style="color:#64748b;line-height:1.7;margin:0 0 20px">
                      Your account has been successfully created. You can now browse thousands of products,
                      add them to your cart, and place orders — all in one place.
                    </p>
                    <div style="background:#fff7ed;border-left:4px solid #e85c2e;border-radius:4px;padding:14px 16px;margin-bottom:24px">
                      <p style="margin:0;color:#92400e;font-size:13px;font-weight:600">🛍️ Start shopping today and enjoy fast delivery!</p>
                    </div>
                    <p style="color:#94a3b8;font-size:12px;margin:0">Thank you for joining InstaBuy. Happy shopping!</p>
                  </div>
                  <div style="background:#f8fafc;padding:16px 32px;text-align:center;border-top:1px solid #e2e8f0">
                    <p style="margin:0;color:#94a3b8;font-size:11px">© 2024 InstaBuy OMS. All rights reserved.</p>
                  </div>
                </div>
                """.formatted(name.isBlank() ? "there" : name);

        sendHtml(toEmail, subject, body);
        log.info("Welcome email sent to {}", toEmail);
    }

    private boolean sendHtml(String to, String subject, String htmlBody) {
        try {
            MimeMessage msg = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(msg, true, "UTF-8");
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(htmlBody, true);
            mailSender.send(msg);
            return true;
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", to, e.getMessage());
            return false;
        }
    }
}
