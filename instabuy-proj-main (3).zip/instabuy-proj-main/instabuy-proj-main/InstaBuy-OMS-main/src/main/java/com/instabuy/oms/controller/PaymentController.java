package com.instabuy.oms.controller;

import com.instabuy.oms.dto.PaymentRequest;
import com.instabuy.oms.dto.PaymentResponse;
import com.instabuy.oms.entity.Payment;
import com.instabuy.oms.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) { this.paymentService = paymentService; }

    @PostMapping
    public ResponseEntity<PaymentResponse> processPayment(@RequestBody PaymentRequest request) {
        return ResponseEntity.ok(paymentService.processPayment(request));
    }

    @GetMapping
    public List<Payment> getAllPayments() { return paymentService.getAllPayments(); }

    @GetMapping("/{id}")
    public Payment getPayment(@PathVariable Long id) { return paymentService.getPaymentById(id); }
}
