package com.instabuy.oms.controller;

import com.instabuy.oms.dto.OrderRequest;
import com.instabuy.oms.dto.OrderResponse;
import com.instabuy.oms.service.OrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) { this.orderService = orderService; }

    @GetMapping
    public List<OrderResponse> listOrders(@RequestParam(required = false) String customerName) {
        if (customerName != null && !customerName.isBlank())
            return orderService.getOrdersByCustomerName(customerName);
        return orderService.getAllOrders();
    }

    @GetMapping("/{id}")
    public OrderResponse getOrder(@PathVariable Long id) { return orderService.toResponse(orderService.getOrderById(id)); }

    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@Validated @RequestBody OrderRequest request) {
        return ResponseEntity.ok(orderService.createOrder(request));
    }

    @PutMapping("/{id}/accept")
    public OrderResponse acceptOrder(@PathVariable Long id) { return orderService.acceptOrder(id); }

    @PutMapping("/{id}/ship")
    public OrderResponse shipOrder(@PathVariable Long id) { return orderService.shipOrder(id); }

    @PutMapping("/{id}/restore")
    public OrderResponse restoreOrder(@PathVariable Long id) { return orderService.restoreOrder(id); }

    @PostMapping("/{id}/cancel")
    public OrderResponse cancelOrder(@PathVariable Long id) { return orderService.cancelOrder(id); }
}
