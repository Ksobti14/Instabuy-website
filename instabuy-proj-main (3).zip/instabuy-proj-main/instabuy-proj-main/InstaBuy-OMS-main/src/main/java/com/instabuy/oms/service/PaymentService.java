package com.instabuy.oms.service;

import com.instabuy.oms.constants.AppConstants;
import com.instabuy.oms.dto.PaymentRequest;
import com.instabuy.oms.dto.PaymentResponse;
import com.instabuy.oms.entity.Payment;
import com.instabuy.oms.enums.PaymentStatus;
import com.instabuy.oms.mapper.PaymentMapper;
import com.instabuy.oms.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderService orderService;
    private final PaymentMapper paymentMapper;

    public PaymentResponse processPayment(PaymentRequest request) {
        log.info("Processing payment for customer: {}", request.getCustomerName());

        Payment payment = paymentMapper.toEntity(request);
        payment.setAmount(request.getAmount() != null ? request.getAmount() : 0.0);
        payment.setStatus(PaymentStatus.PENDING);
        payment = paymentRepository.save(payment);

        try {
            request.getItems().forEach(item -> {
                item.setCustomerName(request.getCustomerName());
                orderService.createOrder(item);
            });
            payment.setStatus(PaymentStatus.SUCCESS);
            paymentRepository.save(payment);
            log.info("Payment {} succeeded, orders created: {}", payment.getId(), request.getItems().size());
            return new PaymentResponse(true, "Payment successful; orders created: " + request.getItems().size(), payment.getId());
        } catch (Exception e) {
            payment.setStatus(PaymentStatus.FAILED);
            paymentRepository.save(payment);
            log.error("Payment {} failed: {}", payment.getId(), e.getMessage());
            return new PaymentResponse(false, "Payment failed: " + e.getMessage(), payment.getId());
        }
    }

    public List<Payment> getAllPayments() {
        log.debug("Fetching all payments");
        return paymentRepository.findAll();
    }

    public Payment getPaymentById(Long id) {
        log.debug("Fetching payment by id: {}", id);
        return paymentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(AppConstants.PAYMENT_NOT_FOUND + id));
    }
}
