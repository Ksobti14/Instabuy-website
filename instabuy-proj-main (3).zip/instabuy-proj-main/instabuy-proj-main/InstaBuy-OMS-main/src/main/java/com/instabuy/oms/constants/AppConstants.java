package com.instabuy.oms.constants;

public final class AppConstants {

    private AppConstants() {}

    // Error messages
    public static final String EMAIL_ALREADY_REGISTERED = "Email already registered";
    public static final String INVALID_CREDENTIALS = "Invalid email or password";
    public static final String PRODUCT_NOT_FOUND = "Product not found: ";
    public static final String ORDER_NOT_FOUND = "Order not found: ";
    public static final String PAYMENT_NOT_FOUND = "Payment not found: ";
    public static final String INSUFFICIENT_STOCK = "Insufficient stock for product: ";
    public static final String ONLY_PLACED_ORDERS_CANCELLED = "Only placed orders can be cancelled";
    public static final String NO_ITEMS_PROVIDED = "No items provided";
    public static final String CUSTOMER_NAME_REQUIRED = "Customer name required";

    // Seed data
    public static final String SKU_1001 = "SKU-1001";
    public static final String SKU_1002 = "SKU-1002";
    public static final String SKU_1003 = "SKU-1003";
}
