package com.instabuy.oms.dto;

import com.instabuy.oms.entity.Product;
import com.instabuy.oms.enums.OrderStatus;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class OrderResponse {
    private Long id;
    private String customerName;
    private Integer quantity;
    private OrderStatus status;
    private LocalDateTime createdAt;
    private Product product;
}
