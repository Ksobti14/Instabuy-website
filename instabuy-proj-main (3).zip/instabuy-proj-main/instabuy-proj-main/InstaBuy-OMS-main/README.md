# InstaBuy OMS Backend

This project is the backend for an order management system built with Spring Boot, REST APIs, MySQL, JPA (Hibernate), and Docker.

## Project Flow

1. Create product catalog and inventory entities using JPA.
2. Build REST APIs for products and orders.
3. Use service layer to enforce business logic and inventory consistency.
4. Persist data in MySQL via Spring Data JPA.
5. Containerize with Docker and orchestrate with Docker Compose.

## Backend Features

- Product CRUD
- Order placement
- Stock validation on order creation
- Order cancellation with inventory rollback
- MySQL persistence
- Auto-seeding default products at startup

## Local Setup

### Backend
1. Build project:
   ```bash
   mvn clean package
   ```

2. Start MySQL and backend with Docker Compose:
   ```bash
   docker-compose up --build
   ```

3. Access backend endpoints:
   - `GET http://localhost:8080/api/products`
   - `GET http://localhost:8080/api/orders`
   - `POST http://localhost:8080/api/orders`

### Frontend
1. Open a second terminal in `frontend`:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

2. Open the site at:
   - `http://localhost:4173`

The frontend uses Vite and proxies API requests to the backend at `http://localhost:8080`.

## Example Order Request

```json
{
  "productId": 1,
  "quantity": 2,
  "customerName": "John Doe"
}
```

## Notes

- Update `src/main/resources/application.properties` for local MySQL credentials if not using Docker.
- The default Docker Compose MySQL password is `change_me`.
