import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import LoginModal from '../components/LoginModal';
import Sidebar from '../Sidebar';
import { getStoredUser } from '../authUser';
import { fmt } from '../currency';
import { ProductImage } from '../productImage.jsx';

export default function Home() {
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [showLogin, setShowLogin] = useState(false);
  const [currentUser, setCurrentUser] = useState(() => getStoredUser());

  const featured = useMemo(() => products.slice(0, 5), [products]);
  const role = currentUser?.role?.toUpperCase();
  const isSeller = role === 'SELLER';
  const isAdmin = role === 'ADMIN';

  useEffect(() => {
    const user = getStoredUser();
    setCurrentUser(user);

    fetch('/api/products')
      .then((r) => r.json())
      .then(setProducts)
      .catch(() => {});

    if (user) {
      const isAdm = ['ADMIN', 'SELLER'].includes(user.role?.toUpperCase());
      const url = isAdm
        ? '/api/orders'
        : `/api/orders?customerName=${encodeURIComponent(
            (user.name || user.email || '').trim()
          )}`;

      fetch(url)
        .then((r) => r.json())
        .then(setOrders)
        .catch(() => {});
    }
  }, [showLogin]);

  const addToCart = (p) => {
    const user = getStoredUser();

    if (!user) {
      setShowLogin(true);
      return;
    }

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const ex = cart.find((c) => Number(c.id) === Number(p.id));
    const discount = Number(p.discountPercent) || 0;
    const salePrice = Number(p.price) * (1 - discount / 100);

    if (ex) {
      ex.quantity = Math.min((Number(ex.quantity) || 1) + 1, p.stock);
      ex.price = salePrice;
      ex.discountPercent = discount;
    } else {
      cart.push({
        id: p.id,
        productId: p.id,
        name: p.name,
        description: p.description,
        price: salePrice,
        originalPrice: Number(p.price),
        discountPercent: discount,
        quantity: 1,
        stock: p.stock,
      });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    window.dispatchEvent(new Event('storage'));
  };

  const quickStats = [
    { label: 'Fast checkout', value: '2 min' },
    { label: 'Seller tools', value: '3 hubs' },
    { label: 'Live catalog', value: products.length || 'Ready' },
  ];

  return (
    <main className={currentUser ? 'landing-shell logged-in-home' : 'landing-shell'}>
      {!currentUser && <Sidebar />}

      {!currentUser && <section className="landing-hero">
        <div className="landing-hero-content">
          <p className="eyebrow">InstaBuy Ecommerce</p>
          <h1>Buy faster. Sell smarter. Track everything.</h1>
          <p className="hero-text">
            A modern shopping and order-management experience for customers,
            sellers, and admins with instant checkout, order visibility, seller
            onboarding, and sales analytics in one place.
          </p>

          <div className="landing-actions">
            <Link to="/login" className="hero-cta">
              Sign in to shop
            </Link>
            <Link to="/seller-register" className="hero-secondary">
              Become a seller
            </Link>
          </div>

          <div className="landing-stats" aria-label="InstaBuy highlights">
            {quickStats.map((stat) => (
              <div key={stat.label}>
                <strong>{stat.value}</strong>
                <span>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="commerce-preview" aria-label="InstaBuy order preview">
          <div className="preview-card preview-card-main">
            <span className="preview-kicker">Today</span>
            <h2>Flash delivery queue</h2>
            <p>{orders.length || 24} active orders moving through InstaBuy.</p>
            <div className="preview-meter">
              <span style={{ width: '72%' }} />
            </div>
          </div>
          <div className="preview-card">
            <span>Catalog</span>
            <strong>{products.length || 128}</strong>
            <small>products ready</small>
          </div>
          <div className="preview-card accent">
            <span>Seller growth</span>
            <strong>+38%</strong>
            <small>monthly revenue</small>
          </div>
        </div>
      </section>}

      <section className="landing-section">
        <div className="section-title">
          <p className="eyebrow">Why InstaBuy</p>
          <h2>Everything your marketplace needs on one clean dashboard.</h2>
        </div>

        <div className="feature-grid">
          <article className="feature-card">
            <span className="feature-icon">01</span>
            <h3>Instant shopping</h3>
            <p>
              Customers can browse, add to cart, checkout, save addresses, and
              track orders without jumping across tools.
            </p>
          </article>
          <article className="feature-card">
            <span className="feature-icon">02</span>
            <h3>Seller onboarding</h3>
            <p>
              New sellers can register their store details and move straight
              into order and catalog management.
            </p>
          </article>
          <article className="feature-card">
            <span className="feature-icon">03</span>
            <h3>Analytics-ready</h3>
            <p>
              Sellers and admins get quick visibility into revenue, orders, and
              product performance.
            </p>
          </article>
        </div>
      </section>

      {isSeller && (
        <section className="seller-snapshot">
          {[
            { label: 'Total Orders', value: orders.length },
            { label: 'Products Listed', value: products.length },
            {
              label: 'Pending Orders',
              value: orders.filter((o) => o.status === 'PLACED').length,
            },
          ].map((s) => (
            <div key={s.label} className="snapshot-card">
              <strong>{s.value}</strong>
              <span>{s.label}</span>
            </div>
          ))}
        </section>
      )}

      {!currentUser && (
        <section className="landing-join">
          <div>
            <p className="eyebrow">Get started</p>
            <h2>Join InstaBuy as a shopper or seller today.</h2>
          </div>
          <div className="landing-actions">
            <Link to="/register" className="checkout-btn">
              Create account
            </Link>
            <Link to="/seller-register" className="hero-secondary dark">
              Seller register
            </Link>
          </div>
        </section>
      )}

      <section className="landing-section">
        <div className="panel-heading">
          <h2>Featured Products</h2>
          {currentUser && (
            <Link to="/products" className="text-link">
              See all products
            </Link>
          )}
        </div>

        {featured.length === 0 ? (
          <p className="empty-state">No products available yet.</p>
        ) : (
          <div className="product-grid">
            {featured.map((p) => {
              const discount = Number(p.discountPercent) || 0;
              const displayPrice = Number(p.price) * (1 - discount / 100);

              return (
                <div key={p.id} className="product-card">
                  <ProductImage product={p} />
                  <p className="product-sku">{p.sku}</p>
                  <h3>{p.name}</h3>
                  <p>{p.description}</p>
                  <div className="stars">4.8 rating</div>
                  <div className="price-box">
                    {discount > 0 && <span className="old-price">{fmt(p.price)}</span>}
                    <span className="new-price">{fmt(displayPrice)}</span>
                  </div>
                  {discount > 0 && <span className="discount-badge">{discount}% off</span>}
                  <div className="product-meta">
                    <span>
                      {p.stock > 0 ? `In Stock (${p.stock})` : 'Out of Stock'}
                    </span>
                  </div>
                  <span className="prime-badge">Fast Delivery</span>
                  {!isSeller && !isAdmin && currentUser && (
                    <button
                      className="checkout-btn"
                      style={{ width: '100%', marginTop: 8 }}
                      onClick={() => addToCart(p)}
                      disabled={p.stock === 0}
                    >
                      {p.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      <LoginModal
        open={showLogin}
        onClose={() => setShowLogin(false)}
        onSuccess={() => setShowLogin(false)}
      />
    </main>
  );
}
