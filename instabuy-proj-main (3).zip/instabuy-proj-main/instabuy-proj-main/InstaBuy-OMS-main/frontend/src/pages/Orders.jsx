import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getStoredUser } from '../authUser';
import { fmt } from '../currency';

const salePrice = (product) =>
  Number(product?.price || 0) * (1 - (Number(product?.discountPercent) || 0) / 100);

const STATUS_LABEL = {
  PLACED: { text: 'Pending Review', color: '#92400e' },
  ACCEPTED: { text: 'Accepted by Seller - Waiting for Admin Shipment', color: '#15803d' },
  SHIPPED: { text: 'Shipped', color: '#1d4ed8' },
  CANCELLED: { text: 'Declined', color: '#b91c1c' },
};

const TABS = ['All', 'Pending', 'Accepted', 'Shipped', 'Declined'];

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState('');
  const [actionError, setActionError] = useState('');
  const [confirmId, setConfirmId] = useState(null);
  const [activeTab, setActiveTab] = useState('All');
  const [currentUser] = useState(() => getStoredUser());
  const role = currentUser?.role?.toUpperCase();
  const isSellerMode = role === 'SELLER';
  const isAdmin = role === 'ADMIN';

  const loadOrders = () => {
    if (!currentUser) {
      setError('Please sign in to view orders');
      return;
    }

    const url = isSellerMode || isAdmin
      ? '/api/orders'
      : `/api/orders?customerName=${encodeURIComponent((currentUser.name || currentUser.email || '').trim())}`;

    fetch(url)
      .then((r) => r.json())
      .then(setOrders)
      .catch(() => setError('Failed to load orders'));
  };

  useEffect(() => {
    loadOrders();
    const refreshId = window.setInterval(loadOrders, 5000);
    const refreshOnFocus = () => loadOrders();
    window.addEventListener('focus', refreshOnFocus);

    return () => {
      window.clearInterval(refreshId);
      window.removeEventListener('focus', refreshOnFocus);
    };
  }, []);

  const doAction = async (url, method) => {
    setActionError('');
    try {
      const res = await fetch(url, { method });
      if (!res.ok) throw new Error(await res.text());
      loadOrders();
    } catch (e) {
      setActionError(e.message || 'Action failed');
    }
  };

  const acceptOrder = (id) => doAction(`/api/orders/${id}/accept`, 'PUT');
  const shipOrder = (id) => doAction(`/api/orders/${id}/ship`, 'PUT');
  const declineOrder = (id) => {
    setConfirmId(null);
    doAction(`/api/orders/${id}/cancel`, 'POST');
  };
  const restoreOrder = (id) => doAction(`/api/orders/${id}/restore`, 'PUT');

  const filteredOrders = orders.filter((order) => {
    if ((!isSellerMode && !isAdmin) || activeTab === 'All') return true;
    if (activeTab === 'Pending') return order.status === 'PLACED';
    if (activeTab === 'Accepted') return order.status === 'ACCEPTED';
    if (activeTab === 'Shipped') return order.status === 'SHIPPED';
    if (activeTab === 'Declined') return order.status === 'CANCELLED';
    return true;
  });

  return (
    <div className="page-shell">
      {confirmId !== null && (
        <div className="modal-overlay">
          <div className="modal-box">
            <h3 style={{ marginBottom: 10 }}>Decline Order #{confirmId}?</h3>
            <p style={{ color: '#565959', fontSize: 13, marginBottom: 20 }}>
              This will cancel the order. You can undo this afterwards if needed.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button className="order-decline-btn" onClick={() => declineOrder(confirmId)}>
                Yes, Decline
              </button>
              <button className="order-undo-btn" onClick={() => setConfirmId(null)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="breadcrumb">
        <Link to="/">Home</Link> <span>/</span>{' '}
        <span>{isSellerMode ? 'Customer Orders' : isAdmin ? 'All Orders' : 'Your Orders'}</span>
      </div>

      <div className="orders-header">
        <h2>{isSellerMode ? 'Customer Orders' : isAdmin ? 'All Orders' : 'Your Orders'}</h2>
        {(isSellerMode || isAdmin) && <span style={{ fontSize: 13, color: '#565959' }}>{orders.length} total orders</span>}
      </div>

      {error && <div className="alert error" style={{ marginBottom: 16 }}>{error}</div>}
      {actionError && <div className="alert error" style={{ marginBottom: 16 }}>{actionError}</div>}

      {(isSellerMode || isAdmin) && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
          {TABS.map((tab) => {
            const count =
              tab === 'All'
                ? orders.length
                : tab === 'Pending'
                  ? orders.filter((o) => o.status === 'PLACED').length
                  : tab === 'Accepted'
                    ? orders.filter((o) => o.status === 'ACCEPTED').length
                    : tab === 'Shipped'
                      ? orders.filter((o) => o.status === 'SHIPPED').length
                      : orders.filter((o) => o.status === 'CANCELLED').length;

            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={activeTab === tab ? 'tab-btn active' : 'tab-btn'}
              >
                {tab} <span className="tab-count">{count}</span>
              </button>
            );
          })}
        </div>
      )}

      {orders.length === 0 && !error ? (
        <div className="panel" style={{ textAlign: 'center', padding: 48 }}>
          <h3 style={{ marginBottom: 8 }}>{isSellerMode || isAdmin ? 'No customer orders yet' : 'No orders placed yet'}</h3>
          <p style={{ color: '#565959', marginBottom: 20 }}>
            {isSellerMode || isAdmin
              ? 'Orders will appear here once customers start shopping.'
              : 'When you place an order, it will appear here.'}
          </p>
          {!isSellerMode && !isAdmin && <Link to="/products" className="checkout-btn">Start Shopping</Link>}
        </div>
      ) : (
        <div className="order-list">
          {filteredOrders.map((order) => {
            const status = STATUS_LABEL[order.status] || { text: order.status, color: '#565959' };
            const productTotal = salePrice(order.product) * Number(order.quantity || 1);

            return (
              <div key={order.id} className="order-card">
                <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', flex: 1 }}>
                  <div style={{ fontSize: 24, background: '#f3f3f3', borderRadius: 6, padding: '8px 12px', flexShrink: 0 }}>
                    #{order.id}
                  </div>
                  <div style={{ flex: 1 }}>
                    <strong style={{ fontSize: 15 }}>Order #{order.id}</strong>
                    {order.product && (
                      <>
                        <p style={{ fontWeight: 600, color: 'var(--amz-text)', marginTop: 2 }}>{order.product.name}</p>
                        {order.product.sku && (
                          <p style={{ fontSize: 11, color: '#2563eb', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.05em' }}>
                            SKU: {order.product.sku}
                          </p>
                        )}
                      </>
                    )}
                    {(isSellerMode || isAdmin) && <p style={{ marginTop: 4 }}>Customer: <strong>{order.customerName}</strong></p>}
                    {order.createdAt && (
                      <p style={{ fontSize: 12, color: 'var(--amz-muted)', marginTop: 2 }}>
                        {new Date(order.createdAt).toLocaleString()}
                      </p>
                    )}
                    <p style={{ color: status.color, fontSize: 13, fontWeight: 600, marginTop: 4 }}>
                      {status.text}
                    </p>
                  </div>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6, minWidth: 170 }}>
                  <span className={`status-badge ${order.status}`}>{order.status}</span>
                  <span style={{ fontSize: 13, color: '#565959' }}>Qty: <strong>{order.quantity}</strong></span>
                  {order.product?.price && (
                    <>
                      <span style={{ fontSize: 12, color: 'var(--amz-muted)' }}>
                        {fmt(salePrice(order.product))} x {order.quantity}
                      </span>
                      <span style={{ fontSize: 16, fontWeight: 800, color: '#b12704' }}>
                        {fmt(productTotal)}
                      </span>
                    </>
                  )}

                  {isSellerMode && order.status === 'PLACED' && (
                    <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
                      <button className="order-accept-btn" onClick={() => acceptOrder(order.id)}>Accept</button>
                      <button className="order-decline-btn" onClick={() => setConfirmId(order.id)}>Decline</button>
                    </div>
                  )}

                  {isSellerMode && order.status === 'ACCEPTED' && (
                    <span style={{ fontSize: 12, color: '#15803d', fontWeight: 700 }}>
                      Sent to admin for shipping
                    </span>
                  )}

                  {isAdmin && order.status === 'ACCEPTED' && (
                    <button className="order-ship-btn" onClick={() => shipOrder(order.id)}>Ship Order</button>
                  )}

                  {isSellerMode && order.status === 'CANCELLED' && (
                    <button className="order-undo-btn" onClick={() => restoreOrder(order.id)}>Undo Decline</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
