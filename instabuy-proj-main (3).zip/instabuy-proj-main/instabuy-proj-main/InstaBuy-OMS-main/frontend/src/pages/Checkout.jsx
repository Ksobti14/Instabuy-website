import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { getStoredUser } from '../authUser';
import { fmt } from '../currency';

function readCart() { try { return JSON.parse(localStorage.getItem('cart') || '[]'); } catch { return []; } }

export default function Checkout() {
  const [cart] = useState(readCart());
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const subtotal = cart.reduce((s, it) => s + (it.price || 0) * (it.quantity || 1), 0);
  const shipping = subtotal > 25 ? 0 : 5.99;
  const total = subtotal + shipping;

  useEffect(() => { if (!cart || cart.length === 0) navigate('/cart'); }, []);

  const handlePay = async (e) => {
    e.preventDefault();
    setError('');
    const user = getStoredUser();
    if (!user) { setError('Please sign in first'); return; }
    setProcessing(true);
    try {
      const res = await fetch('/api/payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart.map(i => ({ productId: Number(i.id || i.productId), quantity: Number(i.quantity) })),
          amount: Number(total.toFixed(2)),
          customerName: (user.name || user.email || '').trim(),
        }),
      });
      if (!res.ok) { const txt = await res.text(); throw new Error(txt || 'Payment failed'); }
      localStorage.removeItem('cart');
      window.dispatchEvent(new Event('storage'));
      navigate('/orders');
    } catch (err) { setError(err.message || 'Payment failed'); }
    finally { setProcessing(false); }
  };

  return (
    <div className="page-shell">
      <div className="breadcrumb">
        <Link to="/">Home</Link> › <Link to="/cart">Cart</Link> › <span>Checkout</span>
      </div>
      <h2 style={{ fontSize: '1.6rem', fontWeight: 700, marginBottom: 20 }}>🔒 Secure Checkout</h2>

      <div className="checkout-layout">
        <div>
          <div className="panel checkout-section">
            <h3>1. Delivery Address</h3>
            <div className="order-form">
              <label>Full Name <input placeholder="John Doe" required /></label>
              <label>Address <input placeholder="123 Main St" required /></label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <label>City <input placeholder="New York" required /></label>
                <label>ZIP Code <input placeholder="10001" required /></label>
              </div>
            </div>
          </div>

          <div className="panel checkout-section">
            <h3>2. Payment Method</h3>
            {error && <div className="alert error" style={{ marginBottom: 12 }}>{error}</div>}
            <form onSubmit={handlePay} className="order-form">
              <label>
                Card Number
                <input required placeholder="4242 4242 4242 4242" maxLength={19} />
              </label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <label>Expiry Date <input required placeholder="MM / YY" /></label>
                <label>CVV <input required placeholder="123" maxLength={4} /></label>
              </div>
              <label>Name on Card <input required placeholder="John Doe" /></label>
              <button className="btn-primary" type="submit" disabled={processing} style={{ marginTop: 8 }}>
                {processing ? '⏳ Processing...' : `🔒 Place Order — ${fmt(total)}`}
              </button>
            </form>
          </div>
        </div>

        <div className="cart-summary" style={{ position: 'sticky', top: 80 }}>
          <h3>Order Summary</h3>
          {cart.map((it, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, marginBottom: 6 }}>
              <span style={{ color: '#565959' }}>{it.name} × {it.quantity}</span>
              <span>{fmt((it.price || 0) * (it.quantity || 1))}</span>
            </div>
          ))}
          <hr style={{ margin: '12px 0', borderColor: '#ddd' }} />
          <div className="cart-total-row"><span>Subtotal</span><span>{fmt(subtotal)}</span></div>
          <div className="cart-total-row"><span>Shipping</span><span>{shipping === 0 ? <span style={{ color: '#007600' }}>FREE</span> : fmt(shipping)}</span></div>
          <div className="cart-total-row grand"><span>Total</span><span style={{ color: '#b12704' }}>{fmt(total)}</span></div>
          <p style={{ fontSize: 11, color: '#565959', marginTop: 12, textAlign: 'center' }}>
            🔒 Your transaction is secured with SSL encryption
          </p>
        </div>
      </div>
    </div>
  );
}
