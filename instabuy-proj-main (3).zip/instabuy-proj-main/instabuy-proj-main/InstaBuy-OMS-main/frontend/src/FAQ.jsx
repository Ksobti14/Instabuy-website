import Sidebar from "./Sidebar";

export default function FAQ() {
  const faqs = [
    {
      question: 'How do I create a customer account?',
      answer: 'Open Register, enter your name, email, and password, then sign in to browse products, add items to cart, and place orders.',
    },
    {
      question: 'How does a seller sign in?',
      answer: 'Sellers use the same Sign In page. After a seller account is created, the navbar shows Products, Add Product, and Orders.',
    },
    {
      question: 'Can sellers add and update products?',
      answer: 'Yes. Sellers can add products and update product name, description, price, stock quantity, and discount percentage.',
    },
    {
      question: 'Will customers see seller discounts?',
      answer: 'Yes. Discounts entered by sellers are shown on the customer product listing with the reduced selling price.',
    },
    {
      question: 'Who accepts customer orders?',
      answer: 'The seller reviews new orders and can accept or decline them from the Orders page.',
    },
    {
      question: 'Who ships an accepted order?',
      answer: 'After a seller accepts an order, the admin sees it as accepted and can use Ship Order to mark it shipped.',
    },
    {
      question: 'How can customers track orders?',
      answer: 'Customers can open My Orders after signing in to see whether an order is placed, accepted, shipped, or declined.',
    },
    {
      question: 'What happens when an order is declined?',
      answer: 'The order moves to Declined status and the reserved stock is restored for that product.',
    },
    {
      question: 'Can a seller restore a declined order?',
      answer: 'Yes. Declined orders can be restored to pending review if stock is available.',
    },
    {
      question: 'How do I contact support?',
      answer: 'You can contact InstaBuy support at support@instabuy.com for account, seller, product, or order help.',
    },
  ];

  return (
    <div>

      <Sidebar />

      <div className="page-with-sidebar page-shell">

        <h1>Frequently Asked Questions</h1>

        {faqs.map((faq) => (
          <div className="panel" key={faq.question}>
            <h3>{faq.question}</h3>
            <p>{faq.answer}</p>
          </div>
        ))}

      </div>

    </div>
  );
}
