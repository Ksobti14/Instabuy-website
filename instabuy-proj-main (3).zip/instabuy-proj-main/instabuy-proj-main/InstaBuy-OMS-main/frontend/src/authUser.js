export function getStoredSellerProfile() {
  try {
    return JSON.parse(localStorage.getItem('sellerProfile') || 'null');
  } catch {
    return null;
  }
}

export function normalizeSellerUser(user) {
  if (!user) return null;

  const sellerProfile = getStoredSellerProfile();
  const profileEmail = sellerProfile?.email?.trim().toLowerCase();
  const userEmail = user.email?.trim().toLowerCase();

  if (profileEmail && userEmail && profileEmail === userEmail && user.role === 'CUSTOMER') {
    const sellerUser = { ...user, role: 'SELLER', name: sellerProfile.storeName || sellerProfile.sellerName || user.name };
    localStorage.setItem('user', JSON.stringify(sellerUser));
    return sellerUser;
  }

  return user;
}

export function getStoredUser() {
  try {
    return normalizeSellerUser(JSON.parse(localStorage.getItem('user') || 'null'));
  } catch {
    return null;
  }
}
