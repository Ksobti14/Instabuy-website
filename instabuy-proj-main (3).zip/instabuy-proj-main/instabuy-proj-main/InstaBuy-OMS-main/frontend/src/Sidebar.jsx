import { Link, useLocation } from 'react-router-dom';

const primaryLinks = [
  {
    to: '/register',
    label: 'Create Account',
    description: 'Start shopping with checkout and order tracking',
  },
  {
    to: '/login',
    label: 'Seller Login',
    description: 'Sign in to manage products, stock, discounts, and orders',
  },
  {
    to: '/seller-register',
    label: 'Seller Registration',
    description: 'Create a seller profile with GST, bank, and pickup details',
  },
  {
    to: '/login',
    label: 'Sign In',
    description: 'Return to your InstaBuy workspace',
  },
];

const infoLinks = [
  {
    to: '/about',
    label: 'About Us',
    description: 'Learn how InstaBuy connects shoppers, sellers, and admins',
  },
  {
    to: '/faq',
    label: 'FAQ',
    description: 'Find answers about shopping, selling, payments, and delivery',
  },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <aside className="sidebar" aria-label="InstaBuy site guide">
      <div className="sidebar-header">
        <p className="sidebar-kicker">InstaBuy Guide</p>
        <h2 className="sidebar-logo">Your marketplace starts here</h2>
        <p>
          Explore the store, learn how InstaBuy works, and choose the right
          path for shopping or selling.
        </p>
      </div>

      <nav className="sidebar-nav" aria-label="Get started">
        {primaryLinks.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={location.pathname === link.to ? 'active' : ''}
          >
            <span>{link.label}</span>
            <small>{link.description}</small>
          </Link>
        ))}
      </nav>

      <div className="sidebar-section">
        <strong>Learn More</strong>
        <nav className="sidebar-nav compact" aria-label="Information pages">
          {infoLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={location.pathname === link.to ? 'active' : ''}
            >
              <span>{link.label}</span>
              <small>{link.description}</small>
            </Link>
          ))}
        </nav>
      </div>

      <div className="sidebar-note">
        <strong>Why InstaBuy?</strong>
        <span>One place for quick shopping, seller onboarding, secure payments, and clear delivery updates.</span>
      </div>
    </aside>
  );
}
