import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { getStoredSellerProfile, getStoredUser } from '../authUser';

export default function NavBar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [user, setUser] = useState(() => getStoredUser());
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [cartCount, setCartCount] = useState(() => {
    try { return JSON.parse(localStorage.getItem('cart') || '[]').length; } catch { return 0; }
  });

  useEffect(() => {
    setUser(getStoredUser());
    setCartCount(() => { try { return JSON.parse(localStorage.getItem('cart') || '[]').length; } catch { return 0; } });
  }, [location]);

  useEffect(() => {
    const onStorage = () => setCartCount(() => { try { return JSON.parse(localStorage.getItem('cart') || '[]').length; } catch { return 0; } });
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const logout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('cart');
    setUser(null);
    setCartCount(0);
    window.dispatchEvent(new Event('storage'));
    navigate('/');
  };

  const isSeller = user?.role === 'SELLER';
  const isAdmin = user?.role === 'ADMIN';
  const sellerProfile = (() => {
    return getStoredSellerProfile();
  })();

  return (
    <nav className="nav">
      <div className="nav-left">
        <Link to="/" className="nav-brand">Insta<span>Buy</span></Link>
        {user && <Link to="/products" className="nav-link">Products</Link>}
        {user && !isSeller && !isAdmin && (
          <Link to="/cart" className="cart-badge">
            Cart {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
          </Link>
        )}
        {isSeller && (
          <>
            <Link to="/add-product" className="nav-link">Add Product</Link>
            <Link to="/orders" className="nav-link">Orders</Link>
          </>
        )}
        {isAdmin && (
          <Link to="/orders" className="nav-link">All Orders</Link>
        )}
        {user && !isSeller && !isAdmin && (
          <Link to="/orders" className="nav-link">My Orders</Link>
        )}
      </div>

      <div className="nav-right">
        {user ? (
          <>
            <div
              style={{ position: 'relative' }}
              onMouseEnter={() => setShowProfileMenu(true)}
              onMouseLeave={() => setShowProfileMenu(false)}
            >
              <span
                className="nav-user-badge"
                title={`${user.name || user.email} (${user.role})`}
                onClick={() => navigate('/orders')}
              >
                {(user.name || user.email || 'U').trim().charAt(0).toUpperCase()}
              </span>
              {showProfileMenu && (
                <div className="profile-menu">
                  <p className="profile-name">{isSeller ? sellerProfile?.storeName || user.name || user.email : user.name || user.email}</p>
                  <p className="profile-role">{isSeller ? 'Seller Account' : user.role}</p>

                  {isSeller ? (
                    <>
                      <div className="seller-hover-summary">
                        <span>Manage catalog, stock, discounts, and customer orders.</span>
                      </div>
                      {(sellerProfile?.gstNumber || sellerProfile?.accountNumber || sellerProfile?.pickupAddress) && (
                        <div className="seller-hover-summary">
                          {sellerProfile?.gstNumber && <span>GST: {sellerProfile.gstNumber}</span>}
                          {sellerProfile?.accountNumber && <span>Account: {sellerProfile.accountNumber}</span>}
                          {sellerProfile?.pickupAddress && <span>Pickup: {sellerProfile.pickupAddress}</span>}
                        </div>
                      )}
                      <button className="profile-menu-btn" onClick={() => navigate('/products')}>
                        View Products & Stock
                      </button>
                      <button className="profile-menu-btn" onClick={() => navigate('/add-product')}>
                        Add Product
                      </button>
                      <button className="profile-menu-btn" onClick={() => navigate('/products')}>
                        Update Price, Stock & Discount
                      </button>
                      <button className="profile-menu-btn" onClick={() => navigate('/orders')}>
                        Customer Orders
                      </button>
                    </>
                  ) : (
                    <button className="profile-menu-btn" onClick={() => navigate('/orders')}>
                      View Orders
                    </button>
                  )}
                </div>
              )}
            </div>
            <button className="nav-logout" onClick={logout}>Sign Out</button>
          </>
        ) : (
          <>
            <Link to="/login" className="nav-link">Sign In</Link>
            <Link to="/register" className="nav-link">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
}
