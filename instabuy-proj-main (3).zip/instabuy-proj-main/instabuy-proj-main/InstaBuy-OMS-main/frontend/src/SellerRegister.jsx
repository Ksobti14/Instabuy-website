import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { normalizeSellerUser } from './authUser';

export default function SellerRegister() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    sellerName: '',
    storeName: '',
    gstNumber: '',
    accountNumber: '',
    ifscCode: '',
    pickupAddress: '',
    phone: '',
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.sellerName,
          email: form.email,
          password: form.password,
          role: 'SELLER',
        }),
      });

      if (!res.ok) {
        let t = await res.text();
        try {
          const j = JSON.parse(t);
          t = j.message || j.error || t;
        } catch {}
        throw new Error(t || 'Seller registration failed');
      }

      const data = await res.json();
      localStorage.setItem(
        'sellerProfile',
        JSON.stringify({
          sellerName: form.sellerName,
          storeName: form.storeName,
          gstNumber: form.gstNumber,
          accountNumber: form.accountNumber,
          ifscCode: form.ifscCode,
          pickupAddress: form.pickupAddress,
          phone: form.phone,
          email: form.email,
        })
      );
      const sellerUser = normalizeSellerUser({
        token: data.token,
        email: data.email,
        name: data.name,
        role: data.role,
      });
      localStorage.setItem('user', JSON.stringify(sellerUser));
      navigate('/products');
    } catch (e) {
      setError(e.message || 'Seller registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-wrapper seller-auth-wrapper">
      <div className="auth-box seller-auth-box">
        <div className="breadcrumb">
          <Link to="/">Home</Link> <span>/</span> <span>Seller Register</span>
        </div>
        <h2>Seller Registration</h2>
        <p className="auth-subtitle">
          Enter your business, banking, pickup, and login details to start
          managing products on InstaBuy.
        </p>

        <div className="seller-form-benefits">
          <span>After login, seller can view products and stock available.</span>
          <span>Seller can add products, update stock, set discounts, and manage customer orders.</span>
        </div>

        {error && <div className="alert error" style={{ marginBottom: 14 }}>{error}</div>}

        <form className="order-form" onSubmit={handleSubmit}>
          <div className="seller-form-grid">
            <label>
              Seller Name
              <input
                type="text"
                name="sellerName"
                value={form.sellerName}
                onChange={handleChange}
                required
                autoFocus
              />
            </label>

            <label>
              Store Name
              <input
                type="text"
                name="storeName"
                value={form.storeName}
                onChange={handleChange}
                required
              />
            </label>

            <label>
              GST Number
              <input
                type="text"
                name="gstNumber"
                value={form.gstNumber}
                onChange={handleChange}
                required
                pattern="[A-Za-z0-9]{10,15}"
                title="Enter a valid GST or tax identifier."
              />
            </label>

            <label>
              Phone Number
              <input
                type="tel"
                name="phone"
                value={form.phone}
                onChange={handleChange}
                required
                pattern="[0-9]{10}"
                title="Enter a 10 digit phone number."
              />
            </label>

            <label>
              Account Number
              <input
                type="text"
                name="accountNumber"
                value={form.accountNumber}
                onChange={handleChange}
                required
                pattern="[0-9]{9,18}"
                title="Enter a valid bank account number."
              />
            </label>

            <label>
              IFSC Code
              <input
                type="text"
                name="ifscCode"
                value={form.ifscCode}
                onChange={handleChange}
                required
                pattern="[A-Za-z]{4}0[A-Za-z0-9]{6}"
                title="Enter a valid IFSC code, such as HDFC0001234."
              />
            </label>

            <label>
              Email
              <input
                type="email"
                name="email"
                value={form.email}
                onChange={handleChange}
                required
              />
            </label>

            <label>
              Password
              <input
                type="password"
                name="password"
                value={form.password}
                onChange={handleChange}
                required
                minLength={6}
              />
            </label>
          </div>

          <label>
            Pickup Address
            <textarea
              name="pickupAddress"
              value={form.pickupAddress}
              onChange={handleChange}
              required
              minLength={12}
            />
          </label>

          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Registering Seller...' : 'Register Seller'}
          </button>
        </form>
      </div>
    </div>
  );
}
