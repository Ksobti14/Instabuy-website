import { Routes, Route, Navigate } from 'react-router-dom';

import NavBar from './components/NavBar';

import Home from './pages/Home';
import Products from './pages/Products';
import AddProduct from './pages/AddProduct';
import Orders from './pages/Orders';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Login from './pages/Login';
import Register from './pages/Register';
import NotFound from './pages/NotFound';

import SellerRegister from './SellerRegister';
import AddressBook from './AddressBook';
import Analytics from './Analytics';
import FAQ from './FAQ';
import About from './About';
import EMI from './EMI';

import ProtectedRoute from './components/ProtectedRoute';
import { getStoredUser } from './authUser';

function AdminGuard({ children }) {

  const user = getStoredUser();

  return user?.role === 'ADMIN' || user?.role === 'SELLER'
    ? <Navigate to="/" replace />
    : children;
}

function App() {

  return (
    <div className="app-shell">

      <NavBar />

      <Routes>

        {/* Main Pages */}

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/products"
          element={
            <ProtectedRoute>
              <Products />
            </ProtectedRoute>
          }
        />

        {/* Customer */}

        <Route
          path="/cart"
          element={
            <AdminGuard>
              <Cart />
            </AdminGuard>
          }
        />

        <Route
          path="/checkout"
          element={
            <AdminGuard>
              <Checkout />
            </AdminGuard>
          }
        />

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />

        {/* Seller */}

        <Route
          path="/seller-register"
          element={<SellerRegister />}
        />

        {/* Addresses */}

        <Route
          path="/address-book"
          element={
            <ProtectedRoute>
              <AddressBook />
            </ProtectedRoute>
          }
        />

        {/* Analytics */}

        <Route
          path="/analytics"
          element={
            <ProtectedRoute>
              <Analytics />
            </ProtectedRoute>
          }
        />

        {/* Info Pages */}

        <Route
          path="/faq"
          element={<FAQ />}
        />

        <Route
          path="/about"
          element={<About />}
        />

        <Route
          path="/emi"
          element={<EMI />}
        />

        {/* Admin */}

        <Route
          path="/add-product"
          element={
            <ProtectedRoute role="SELLER">
              <AddProduct />
            </ProtectedRoute>
          }
        />

        {/* Orders */}

        <Route
          path="/orders"
          element={
            <ProtectedRoute>
              <Orders />
            </ProtectedRoute>
          }
        />

        {/* 404 */}

        <Route
          path="*"
          element={<NotFound />}
        />

      </Routes>

      <footer className="site-footer">

        <p>
          © 2026 InstaBuy Ecommerce —
          Built with ❤️ |
          <a href="/"> Home</a> ·
          <a href="/products"> Products</a> ·
          <a href="/orders"> Orders</a> ·
          <a href="/faq"> FAQ</a> ·
          <a href="/about"> About</a>
        </p>

      </footer>

    </div>
  );
}

export default App;
